const express = require("express");
const mongoose = require("mongoose");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();
const server = http.createServer(app);

// Socket.io initialization for Real-time features
const io = new Server(server, {
  cors: { origin: "*" },
});

app.use(express.json());
app.use(cors());

// --- Configuration (Directly in code) ---
const MONGO_URI = "mongodb+srv://admin:admin@cluster0.pnciqvn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
const JWT_SECRET = "sonam_secret_key_123";

// 1. Database Connection
mongoose
  .connect(MONGO_URI)
  .then(() => console.log("✅ SocialDB (Atlas) Connected Successfully"))
  .catch((err) => console.error("❌ Connection Error:", err.message));

// 2. Schemas & Models
const PostSchema = new mongoose.Schema({
  username: String,
  content: String,
  likes: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});
const Post = mongoose.model("Post", PostSchema);

// 3. Real-time Logic (WebSockets)
io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("like_post", async (postId) => {
    const post = await Post.findByIdAndUpdate(
      postId,
      { $inc: { likes: 1 } },
      { new: true },
    );
    io.emit("update_likes", post); // Sabko update bhejta hai
  });

  socket.on("disconnect", () => console.log("User disconnected"));
});

// 4. API Routes
app.get("/api/posts", async (req, res) => {
  const posts = await Post.find().sort({ createdAt: -1 });
  res.json(posts);
});

app.post("/api/posts", async (req, res) => {
  const newPost = await Post.create(req.body);
  io.emit("new_post", newPost); // Real-time feed update
  res.status(201).json(newPost);
});

// Analytics Placeholder
app.get("/api/analytics", (req, res) => {
  res.json({ followers: "5.2K", engagement: "12%", reach: "10K+" });
});

const PORT = 5000;
server.listen(PORT, () =>
  console.log(`🚀 Dashboard Server running on http://localhost:${PORT}`),
);